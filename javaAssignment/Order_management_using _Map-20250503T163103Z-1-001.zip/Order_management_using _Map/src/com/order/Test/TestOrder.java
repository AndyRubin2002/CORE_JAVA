package com.order.Test;

import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.order.Entity.Customer;
import com.order.Entity.Item;
import com.order.Service.OrderService;
import com.order.Service.OrderServiceImpl;

public class TestOrder {

	public static void main(String[] args) {
		OrderService os = new OrderServiceImpl();
		Scanner sc = new Scanner(System.in);
		
		int ch;
		
		do {
			System.err.println("1. add new order "); 
			System.err.println("2. display all ");
			System.err.println("3. Delete order ");
			System.err.println("4. modify customer mobile ");
			System.err.println("5. add new item in existing order ");
			System.err.println("6. Modify qty for existing order for a particular item");
			System.err.println("7. delete item from existing order");
			System.err.println("8. display orders of a customer");
			System.err.println("9. display orders that has some particular item");
			System.err.println("10. calculate bill for a particular order");
			System.err.println("11. Exit.");
			System.err.println("Enter your Choice :");
			ch= sc.nextInt();
			
			switch(ch) {
			
			case 1:
				boolean status = os.addNewOrder();
				if(status)
				{
					System.out.println("Added Succesfully");
				}else {
					System.err.println("Duplicate Entry");
				}
				break;
				
			case 2:
				Map<Customer,List<Item>> cmap = os.showAll();
				cmap.forEach((s,lst)->{
					System.out.println(s+"-->");
					System.out.println(lst);
				});
				break;
				
			case 3:
				System.out.println("Enter Customer Id :");
				int cid = sc.nextInt();
				if(os.deleteOrder(cid))
				{
					System.out.println("Deleted");
				}else {
					System.err.println("Customer Not found");
				}
				break;
				
			case 4:
				System.out.println("Enter Customer Id :");
				cid = sc.nextInt();
				System.out.println("Enter Customer mob :");
				String mob = sc.next();
				if(os.modifyMob(cid,mob))
				{
					System.out.println("Mobile Number is Modfied");
				}else {
					System.err.println("Customer Not found");
				}
				break;
			case 5:
				System.out.println("Enter Customer Id :");
				cid = sc.nextInt();
				if(os.addItem(cid))
				{
					System.out.println("Item is Added");
				}else {
					System.err.println("Customer Not found");
				}
				break;
			case 6:
				System.out.println("Enter Customer Id :");
				cid = sc.nextInt();
				System.out.println("Enter item itemno :");
				int iid = sc.nextInt();
				System.out.println("Enter item qty :");
				int qty = sc.nextInt();
				if(os.modfiyQty(cid,iid,qty))
				{
					System.out.println("Item qty is updated");
				}else {
					System.err.println("Customer Not found");
				}
				break;

			case 7:
				System.out.println("Enter Customer Id :");
				cid = sc.nextInt();
				System.out.println("Enter item itemno :");
				iid = sc.nextInt();
				if(os.deleteItem(cid,iid))
				{
					System.out.println("Item is deleted");
				}else {
					System.err.println("Customer Not found");
				}
				break;
			case 8:
				System.out.println("Enter Customer Id :");
				cid = sc.nextInt();
				List<Item> list = os.listOfOrder(cid);
				if(list != null) {
//					list.forEach(System.out::println);
					list.forEach(e->System.out.println(e));
				}else {
					System.err.println("Customer Not found");
				}
				break;
			case 9:
				System.out.println("Enter Customer Id :");
				cid = sc.nextInt();
				System.out.println("Enter item name :");
				String itemn = sc.next();
				list = os.listOfItemByName(cid,itemn);
				if(list != null) {
					System.out.println(list);
				}else {
					System.err.println("Customer Not found");
				}
				break;
			case 10:
				System.out.println("Enter Customer Id :");
				cid = sc.nextInt();
				
				double total = os.OrderAmt(cid);
				if(total != 0) {
					System.out.println("Item Total Amount :"+total);
				}else {
					System.err.println("Customer Not found");
				}
				break;
			case 11:
				sc.close();
				System.out.println("Thank you ...........");
				break;
			default: 
				System.err.println("Wrong Choice ");
				break;
			}
			
		}while(ch!=11);

	}

}
