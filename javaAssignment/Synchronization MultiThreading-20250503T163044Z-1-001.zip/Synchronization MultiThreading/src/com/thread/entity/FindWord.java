package com.thread.entity;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class FindWord {
	public void search(String word) {
		try(BufferedReader br = new BufferedReader(new FileReader("test.txt"));) {
			String line = br.readLine();
			boolean flag=false;
			while(line != null) {
				Thread.sleep(300);
				if(!line.equalsIgnoreCase(word)) {
					flag = false;
					line=br.readLine();
				}else {
					flag = true;
					 break;
				}
			}
			if(flag)
   			 System.out.println("Found  "+word);
   		 else
   			 System.out.println("Not found "+word);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}


