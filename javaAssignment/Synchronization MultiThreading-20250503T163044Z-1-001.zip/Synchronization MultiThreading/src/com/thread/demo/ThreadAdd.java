package com.thread.demo;

import com.thread.entity.MyClass;

public class ThreadAdd extends  Thread{
	private MyClass mc;
	
	

	public ThreadAdd(MyClass mc) {
		super();
		this.mc = mc;

	}


	public void run()
	{
		for(int i =1;i<5;i++)
		{
			mc.add(i);
		}
	}

}
