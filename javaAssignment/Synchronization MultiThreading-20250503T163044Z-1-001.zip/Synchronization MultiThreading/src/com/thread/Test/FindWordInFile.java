package com.thread.Test;

import com.thread.demo.SearchThread;
import com.thread.entity.FindWord;

public class FindWordInFile {

	public static void main(String[] args) {
		
		String[] arr = {"ram","sham","yellow","orange","black","grey"};
		FindWord fs =new FindWord();
		
		for(String str : arr) {
			SearchThread st = new SearchThread(fs,str);
			st.start();
		}
		
		
	}

}
