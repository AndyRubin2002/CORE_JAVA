package Second.java;

import java.util.Scanner;


public class ArrayMenu {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		ArrayServices as = new ArrayServices();
		int [][] arr = new int[3][3];
		int [][] arr1 = new int[3][3];
		System.out.println("Enter 1st array element :");
		arr = as.acceptElement(arr);
		System.out.println("Enter 2nd array element :");
		arr1 = as.acceptElement(arr1);
		
		int ch;
		do {
			System.out.println("----------------------------------------");
			System.out.println(" 1.Sum of 2D Array \n 2.Row sum of 2D Array \n 3.Column sum Of 2D array \n 4.Transpose Matrix \n 5. Addition of Matrix \n 6.Multiplication of Matrix \n 7.Exit");
			System.out.println("----------------------------------------");
			System.out.println("Enter the Choice");
			ch = sc.nextInt();
			
			
			
			switch(ch) {
			
			case 1: as.display(arr);
					as.sumArray(arr);
					break;
					
			case 2: as.display(arr);
					as.rowSum(arr);
					break;
					
			case 3:	as.display(arr);
					as.colSum(arr);
					break;
					
			case 4: as.display(arr);
					as.transpose(arr);
					break;
					
			case 5: as.display(arr);
					as.display(arr1);
					as.matrixAdd(arr, arr1);
					break;
					
			case 6: as.display(arr);
					as.display(arr1);
					as.matrixMul(arr, arr1);
					break;
					
			case 7: 
					sc.close();
					System.out.println("Exit");
					break;
			
			default: System.err.println("You enter the wrong choice");
					break;
			}
			
			
		}while(ch!=7);
		
		
		
		
	}
	

}
