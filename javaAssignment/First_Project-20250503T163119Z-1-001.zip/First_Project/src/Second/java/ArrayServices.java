package Second.java;

import java.util.Scanner;

public class ArrayServices {
	
	//accept Elements
		public int[][] acceptElement(int[][] arr) {
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter the array elements :");
			
			for(int i=0;i<arr.length;i++)
			{
				for(int j=0;j<arr[i].length;j++)
				{
					arr[i][j] = sc.nextInt();
				}
			}
			sc.close();
		return arr;
		
		}
	
	//Display Elements
	public void display(int[][] arr) {
		
		System.out.println("array elements :");
		for(int i=0;i<arr.length;i++)
		{
			for(int j=0;j<arr[i].length;j++)
			{
				System.out.print(arr[i][j]+ "\t"); 
			}
			System.out.println();
		}
	}
	
	// sum of all elements
	public void sumArray(int[][] arr)
	{
		int sum=0;
		for(int i = 0; i<arr.length; i++)
		{
			for(int j = 0; j<arr[0].length; j++) 
			{
				sum += arr[i][j];
			}
			
		}
		
		System.out.println("Sum of Elements :"+sum);
	
	}
	
	//row wise some
	public void rowSum(int[][] arr)
	{
		for(int i = 0; i<arr.length; i++)
		{
			int sum = 0;
			for(int j = 0; j<arr[0].length; j++) 
			{
				 sum += arr[i][j];
			}
			System.out.println("sum of row "+ (i+1) +" is : " + sum);	
		}	
	}
	
	//col wise some
		public void colSum(int[][] arr)
		{
			for(int i = 0; i<arr.length; i++)
			{
				int sum = 0;
				for(int j = 0; j<arr[0].length; j++) 
				{
					 sum += arr[j][i];
				}
				System.out.println("sum of col "+ (i+1) +" is : " + sum);	
			}	
		}
	
		//Transpose of matrix
		public void transpose(int[][] arr)
		{
			int [][] tra = new int[3][3];
			for(int i = 0; i<arr.length; i++)
			{
				for(int j = 0; j<arr[0].length; j++) 
				{
					 tra[i][j] = arr[j][i];
				}	
			}
			
			System.out.println("Transpose of Matrix :");
			display(tra);
		}
		
		
		//ADD array
		public void matrixAdd(int[][] arr, int[][] arr1)
		{
			int [][] tra = new int[3][3];
			for(int i = 0; i<arr.length; i++)
			{
				for(int j = 0; j<arr[0].length; j++) 
				{
					 tra[i][j] = arr[i][j]+arr1[i][j];
				}	
			}
					
			System.out.println("Addition of Matrix :");
			display(tra);
		}
		
		
		//multiplication array
		public void matrixMul(int[][] arr, int[][] arr1)
		{
			int [][] mul = new int[3][3];
			for(int i = 0; i<arr.length; i++)
			{
				for(int j = 0; j<arr[0].length; j++) 
				{
					for(int k = 0; k<arr.length; k++) {
							mul[i][j] +=  arr[i][k]*arr1[k][j]; 
						}
				}	
			}		
			System.out.println("Multiplication of Matrix :");
			display(mul);
		}
	
	
}
