package IETCDAC;

public class Exmple1 {

	public static void main(String[] args) {
		String str = "Hello Welcome";
		//trim()
		System.out.println(str);
		System.out.println(str.trim());
		System.out.println(str.startsWith(" "));
		System.out.println(str.endsWith(" "));
		String str2 = str.intern();
		System.out.println(str2);
		String c = "abc".substring(2,3);
		System.out.println(c);
		System.out.println(str.replace("Hello", "Bye"));
	}

}
