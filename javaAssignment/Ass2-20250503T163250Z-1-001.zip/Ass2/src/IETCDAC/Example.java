package IETCDAC;

public class Example {

	public static void main(String[] args) {
		ServiceExample se = new ServiceExample(23,"Dinesh",37467836465l);
		System.out.println(se);

	}

}
