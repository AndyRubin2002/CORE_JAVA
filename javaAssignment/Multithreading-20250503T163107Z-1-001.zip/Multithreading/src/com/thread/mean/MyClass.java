package com.thread.mean;

public class MyClass {
	public int factorial(int n) {
		int fact = 1;
		for(int i =1; i<=n; i++) {
			fact *= i;
		}
		
		return fact;
	}
	
	public void isPrime(int n) {
		for(int i = 2; i<n/2; i++) {
			if(n%i != 0) {
				System.out.println(n+" is Prime Number");
				break;
			}
		}
		System.out.println(n+" Not prime");
	}
	
	public void table(int n)
	{
		for(int i=1;i<=10;i++)
		{
			System.out.println(n*i);
		}
	}
}
