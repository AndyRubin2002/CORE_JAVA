package com.thread.myclass;

import com.thread.mean.MyClass;

public class MyThreadClass extends Thread{
	private MyClass obj;
	private int n;
	

	public MyThreadClass(MyClass obj, int n) {
		super();
		this.obj = obj;
		this.n = n;
	}


	public void run()
	{
		System.out.println(obj.factorial(n));
	}

}
