package com.city.Entity;

import java.util.List;
import java.util.Objects;

public class City {
	private String city;
	private List<String> trees;
	public City(String city) {
		super();
		this.city = city;
	}
	public City(String city, List<String> trees) {
		super();
		this.city = city;
		this.trees = trees;
	}
	public String getCity() {
		return city;
	}
	public List<String> getTrees() {
		return trees;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public void setTrees(List<String> trees) {
		this.trees = trees;
	}
	@Override
	public String toString() {
		return "City [city=" + city + ", trees=" + trees + "]";
	}
	@Override
	public int hashCode() {
		return Objects.hash(city);
	}
	@Override
	public boolean equals(Object obj) {
		
		City other = (City) obj;
		return Objects.equals(city, other.city);
	}
	
	
	
}
