package com.city.DAO;

import java.util.ArrayList;
import java.util.List;

import com.city.Entity.City;

public class CityDaoImpl implements CityDao {
	static List<City> clist= new ArrayList<>();
	
	static {
		List<String> tree = new ArrayList<>();
		tree.add("Peepal");
		tree.add("Gulmohar");
		tree.add("Coconut");
		clist.addAll("Mumbai", tree);
		

	}
}
