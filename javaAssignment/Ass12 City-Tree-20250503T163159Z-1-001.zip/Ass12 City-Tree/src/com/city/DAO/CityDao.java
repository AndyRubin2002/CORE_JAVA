package com.city.DAO;

public interface CityDao {

}
