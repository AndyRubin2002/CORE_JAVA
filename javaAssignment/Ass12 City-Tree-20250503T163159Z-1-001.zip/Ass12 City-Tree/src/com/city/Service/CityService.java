package com.city.Service;

public interface CityService {

}
