package com.city.Service;

public class CityServiceImpl implements CityService {

}
