package com.demo.Services;

import java.util.List;

import com.demo.Entity.Emp;
import com.demo.Exception.SalaryException;

public interface EmpServices {

	boolean addEmployees(int ch) throws SalaryException;

	List<Emp> DisplayEmp();

	Emp findById(String id);

	List<Emp> findByName(String name);

	boolean deleteEmp(String id);

	boolean modifyEmp(String id, String name);

	List<Emp> sortByName();

	List<Emp> sortById();

}
