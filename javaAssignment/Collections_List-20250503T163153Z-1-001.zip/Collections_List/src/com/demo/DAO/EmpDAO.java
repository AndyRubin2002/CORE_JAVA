package com.demo.DAO;

import java.util.List;

import com.demo.Entity.Emp;

public interface EmpDAO {

	boolean save(Emp e);

	List<Emp> findAll();

	Emp getById(String id);

	List<Emp> findByName(String name);

	boolean deleteEmp(String id);

	boolean updateName(String id, String name);

	List<Emp> sortByN();

	List<Emp> sortById();
	

}
