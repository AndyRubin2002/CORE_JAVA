import java.util.ArrayList;
import java.util.Scanner;

public class TeamService {
	Scanner sc = new Scanner(System.in);
	ArrayList<Team> team = new ArrayList<>();
	static int cnt =1;
	
	//Team Creation / Accept team Details
	public void acceptTeam() {
		Team t;
		System.out.println("Enter the Team Name :");
		String name = sc.next();
		System.out.println("Enter the Team Coachname :");
		String cname = sc.next();
		sc.nextLine();
		
		Player[] arr = new Player[11];
		for(int i = 0; i<11; i++) {
			 arr[i] = new Player(); 
	            arr[i].setId(i + 1);
	            
	            System.out.println("Enter the Player Name"+(i+1)+" :");
	            String pname = sc.next();
	            arr[i].setName(pname);
	            
	            System.out.println("Enter the Player Category:");
	            String cat = sc.next();
	            arr[i].setCategory(cat);
		}
		ArrayList<Player> players = new ArrayList<>();
		for(Player p : arr) {
			players.add(p);
		}
		t =new Team(cnt,name,cname,players);
		cnt++;
		team.add(t);
	}
	
	
	//Delete Team
	public boolean removeTeam(int teamid) {
		for(Team t : team) {
			if(t.getTeamid() == teamid) {
				team.remove(t);
				return true;
			}
		}
		return false;
		
	}
	
	//Remove a Player from Team
	public boolean removePlayer(int id) {
		for(Team t : team) {
			for(int i = 0; i<t.getPlayers().size(); i++) {
				if(t.getPlayers().get(i).getId() == id) {
					t.getPlayers().remove(i);
					return true;
				}
			}
		}
		return false;
	}
	
	//Display Batsman 
	public void displayBatsman() {
		for(Team t : team) {
			for(int i = 0; i<t.getPlayers().size(); i++) {
				if(t.getPlayers().get(i).getCategory().equalsIgnoreCase("batsman")) {
					System.out.println(t.getPlayers().get(i));
				}
			}
		}
	}
	
	//Display the players by Specification
	public void displaySpeciality(String spe) {
		for(Team t : team) {
			for(int i = 0; i<t.getPlayers().size(); i++) {
				if(t.getPlayers().get(i).getCategory().equalsIgnoreCase(spe)) {
					System.out.println(t.getPlayers().get(i));
				}
			}
		}
	}
	
	//Add new player to the team
	public boolean addPlayer(int teamid) {
		for(Team t : team) {
			if(t.getTeamid() == teamid) {
				Player p = new Player();
				System.out.println("Enter the Player id:");
				int id = sc.nextInt();
	            p.setId(id);
	            
	            System.out.println("Enter the Player Name:");
	            String pname = sc.next();
	            p.setName(pname);
	            
	            System.out.println("Enter the Player Category:");
	            String cat = sc.next();
	            p.setCategory(cat);
				
	            t.getPlayers().add(p);
	            return true;
			}
		}
		return false;
		
	}
	
	//Changing the coach
	public boolean modifyCoach(int teamid, String Coach) {
		for(Team t : team) {
			if(t.getTeamid() == teamid) {
				t.setCoachname(Coach);
				return true;
			}
		}
		return false;
		
	}
	
	// Displaying  Teams
	public void displayTeam() {
		System.out.println(team);
	}
	
	
}
