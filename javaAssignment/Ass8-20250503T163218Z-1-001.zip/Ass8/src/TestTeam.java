import java.util.Scanner;



public class TestTeam {

	public static void main(String[] args) {
		int choice=0;
		Scanner sc=new Scanner(System.in);
		TeamService ts = new TeamService();
		do {
			System.out.println("1. Add new Team");
			System.out.println("2. Delete a Team");
			System.out.println("3. Delete a Player from Team (Accept Player ID to Delete)");
			System.out.println("4. Display All Batsmen");
			System.out.println("5. Display All Players with a Speciality (Accept Speciality from User)");
			System.out.println("6. Add a New Player in a Team");
			System.out.println("7. Modify Coach of a Team");
			System.out.println("8. display teams");
			System.out.println("9. Exit");
			System.out.println("Enter the Choice:");

		choice=sc.nextInt();
		
		switch(choice)
		{
		
		case 1:
				ts.acceptTeam();
			break;
			
		case 2:
			System.out.println("Enter the teamid :");
			int tid = sc.nextInt();
			if(ts.removeTeam(tid)) {
				System.out.println("team is deleted");
			}else {
				System.out.println("team not found");
			}
				
			break;
			
		case 3:
			System.out.println("Enter the player id :");
			int pid = sc.nextInt();
			if(ts.removePlayer(pid)) {
				System.out.println("Player is deleted");
			}else {
				System.out.println("Player not found");
			}
			  break;
			  
		case 4: 
			  ts.displayBatsman();
			  break;
			  
		case 5: 
			System.out.println("Enter the player Speciality");
			String sp = sc.next();
			ts.displaySpeciality(sp);
			  break;	
			  
		case 6: 
			System.out.println("Enter the teamid :");
			tid = sc.nextInt();
			if(ts.addPlayer(tid)) {
				System.out.println("Player Added");
			}else {
				System.out.println("team not found");
			}
			  break;
			  
		case 7: 
			System.out.println("Enter the teamid :");
			tid = sc.nextInt();
			System.out.println("Enter New Coach Name :");
			String name = sc.next();
			if(ts.modifyCoach(tid,name)) {
				System.out.println("Coach Change Success");
			}else {
				System.out.println("team not found");
			}
			  break;  
			  
		case 8:
			ts.displayTeam();
			break;
			
		case 9:
			sc.close();
			System.out.println("Exit.....");
			break;
			
		default: 
			System.out.println("You enter wrong Case");
			break;
		}

	}while(choice!=9);

	}

}
