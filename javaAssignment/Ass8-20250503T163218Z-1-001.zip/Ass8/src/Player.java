
public class Player {
	private int id;
	private String name;
	private String Category;
	
	public Player() {
		this.id = 0;
		this.name = null;
		Category = null;
	}

	public Player(int id, String name, String category) {
		this.id = id;
		this.name = name;
		Category = category;
	}

	public int getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	public String getCategory() {
		return Category;
	}
	public void setId(int id) {
		this.id = id;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setCategory(String category) {
		Category = category;
	}
	@Override
	public String toString() {
		return "Player [id=" + id + ", name=" + name + ", Category=" + Category + "]\n";
	}
	
	
}
