package com.team.Dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.team.Entity.Player;
import com.team.Entity.Team;



public class TeamDaoImpl implements TeamDao {
	static List<Team> team = new ArrayList<>();
	static {
		
		List<Player> pl = new ArrayList<>();
		pl.add(new Player(1, "Shaik Rasheed", "BAT"));
		pl.add(new Player(2, "Rachin Ravindra", "BAT"));
		pl.add(new Player(3, "Ayush Mhatre", "BAT"));
		pl.add(new Player(4, "Ravindra Jadeja", "ALL-ROUNDER"));
		pl.add(new Player(5, "Shivam Dube", "ALL-ROUNDER"));
		pl.add(new Player(6, "Vijay Shankar", "ALL-ROUNDER"));
		pl.add(new Player(7, "Jamie Overton", "BOWLER"));
		pl.add(new Player(8, "MS Dhoni", "WK"));
		pl.add(new Player(9, "Noor Ahmad", "BOWLER"));
		pl.add(new Player(10, "Khaleel Ahmed", "BOWLER"));
		pl.add(new Player(11, "Matheesha Pathirana", "BOWLER"));
		
		team.add(new Team(1, "CSK", "Suresh", pl));
		
		
		List<Player> pl1 = new ArrayList<>();
		pl1.add(new Player(1, "Virat Kohli", "BAT"));
		pl1.add(new Player(2, "Phil Salt", "BAT"));
		pl1.add(new Player(3, "Devdutt Padikkal", "BAT"));
		pl1.add(new Player(4, "Rajat Patidar", "BAT"));
		pl1.add(new Player(5, "Tim David", "ALL-ROUNDER"));
		pl1.add(new Player(6, "Jitesh Sharma", "WK"));
		pl1.add(new Player(7, "Krunal Pandya", "ALL-ROUNDER"));
		pl1.add(new Player(8, "Romario Shepherd", "ALL-ROUNDER"));
		pl1.add(new Player(9, "Bhuvneshwar Kumar", "BOWLER"));
		pl1.add(new Player(10, "Josh Hazlewood", "BOWLER"));
		pl1.add(new Player(11, "Yash Dayal", "BOWLER"));

		team.add(new Team(2, "RCB", "Rajat Patidar", pl1));


	}
	
	
	
	@Override
	public void save(Team t) {
		team.add(t);
		
	}


	@Override
	public boolean deleteTeam(int tid) {
		
		for(Team t :team)
		{
			if(t.getTeamid()==tid)
			{
				team.remove(t);
				return true;
			}
		}
		return false;
	}



	@Override
	public boolean deletePlayer(int tid, int pid) {
		
		for(Team t : team) {
			if(t.getTeamid()==tid) {
				Iterator<Player> it = t.getPlayers().iterator();
				while(it.hasNext())
				{
					Player p = it.next();
					
					if(p.getId()==pid)
					{
						it.remove();
						return true;
					}
				}
				
			}
		}
		return false;
	}



	@Override
	public void getTeam() {
		team.forEach(System.out::println);
		
	}



	@Override
	public void findBatsman(int tid) {
		
		for(Team t : team) {
			if(t.getTeamid()==tid) {
				Iterator<Player> it = t.getPlayers().iterator();
				while(it.hasNext())
				{
					Player p = it.next();
					
					if(p.getCategory().equalsIgnoreCase("Bat"))
					{
						System.out.println(p);
					}
				}
				
			}
		}
		
		
		
	}



	@Override
	public void showSprciality(int tid, String sp) {
		for(Team t : team) {
			if(t.getTeamid()==tid) {
				Iterator<Player> it = t.getPlayers().iterator();
				while(it.hasNext())
				{
					Player p = it.next();
					
					if(p.getCategory().equalsIgnoreCase(sp))
					{
						System.out.println(p);
					}
				}
				
			}
		}
		
	}


	@Override
	public boolean addPlayer(int tid,Player player) {
		for(Team t : team) {
			if(t.getTeamid() == tid) {
				t.getPlayers().add(player);
				return true;
			}
		}
		return false;
	}


	@Override
	public boolean updateCoach(int tid, String name) {
		for(Team t : team) {
			if(t.getTeamid() == tid) {
				t.setCoachname(name);
				return true;
			}
		}
		return false;
	}
	
	
	
	
	
	
	
	
	
	
	
/*	
	
	
	//Team Creation / Accept team Details
	public void acceptTeam() {
		
	}
	
	
	//Delete Team
	public boolean removeTeam(int teamid) {
		for(Team t : team) {
			if(t.getTeamid() == teamid) {
				team.remove(t);
				return true;
			}
		}
		return false;
		
	}
	
	//Remove a Player from Team
	public boolean removePlayer(int id) {
		for(Team t : team) {
			for(int i = 0; i<t.getPlayers().size(); i++) {
				if(t.getPlayers().get(i).getId() == id) {
					t.getPlayers().remove(i);
					return true;
				}
			}
		}
		return false;
	}
	
	//Display Batsman 
	public void displayBatsman() {
		for(Team t : team) {
			for(int i = 0; i<t.getPlayers().size(); i++) {
				if(t.getPlayers().get(i).getCategory().equalsIgnoreCase("batsman")) {
					System.out.println(t.getPlayers().get(i));
				}
			}
		}
	}
	
	//Display the players by Specification
	public void displaySpeciality(String spe) {
		for(Team t : team) {
			for(int i = 0; i<t.getPlayers().size(); i++) {
				if(t.getPlayers().get(i).getCategory().equalsIgnoreCase(spe)) {
					System.out.println(t.getPlayers().get(i));
				}
			}
		}
	}
	
	//Add new player to the team
	public boolean addPlayer(int teamid) {
		for(Team t : team) {
			if(t.getTeamid() == teamid) {
				Player p = new Player();
				System.out.println("Enter the Player id:");
				int id = sc.nextInt();
	            p.setId(id);
	            
	            System.out.println("Enter the Player Name:");
	            String pname = sc.next();
	            p.setName(pname);
	            
	            System.out.println("Enter the Player Category:");
	            String cat = sc.next();
	            p.setCategory(cat);
				
	            t.getPlayers().add(p);
	            return true;
			}
		}
		return false;
		
	}
	
	//Changing the coach
	public boolean modifyCoach(int teamid, String Coach) {
		for(Team t : team) {
			if(t.getTeamid() == teamid) {
				t.setCoachname(Coach);
				return true;
			}
		}
		return false;
		
	}
	
	// Displaying  Teams
	public void displayTeam() {
		System.out.println(team);
	}


	
	*/

}
