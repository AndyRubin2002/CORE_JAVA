import java.util.ArrayList;

public class Team {
	private int teamid;
	private String tname, coachname;
	private ArrayList<Player> players;
	
	public Team() {
		super();
	}

	public Team(int teamid, String tname, String coachname, ArrayList<Player> players) {
		super();
		this.teamid = teamid;
		this.tname = tname;
		this.coachname = coachname;
		this.players = players;
	}

	public int getTeamid() {
		return teamid;
	}

	public String getTname() {
		return tname;
	}

	public String getCoachname() {
		return coachname;
	}

	public ArrayList<Player> getPlayers() {
		return players;
	}

	public void setTeamid(int teamid) {
		this.teamid = teamid;
	}

	public void setTname(String tname) {
		this.tname = tname;
	}

	public void setCoachname(String coachname) {
		this.coachname = coachname;
	}

	public void setPlayers(ArrayList<Player> players) {
		this.players = players;
	}

	@Override
	public String toString() {
		return "Team [teamid=" + teamid + ", tname=" + tname + ", coachname=" + coachname + ", players=" + players
				+ "]\n";
	}
	
	
	
	
}
