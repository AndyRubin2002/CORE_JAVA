
public class A implements Interface1, Interface2{

	public void m1()
	{
		System.out.println("m1");
	}
	public void m2()
	{
		System.out.println("m2");
	}
	
	public void m4()
	{
		System.out.println("m4");
	}
	

	
}
