package Generic;

public class TestInterface {

	public static void main(String[] args) {
		
		
		Interface <Integer, Double> m = (x,y)->{
			return (int) (x+y);
		};
		System.out.println(m.m1(2.6, 4.8));

	}

	

}
