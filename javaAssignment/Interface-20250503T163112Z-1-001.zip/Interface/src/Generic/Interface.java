package Generic;

public interface Interface<T,S> {
	
	T m1(S x, S y);

}
