
public class Person {
	private String id;
	private String name;
	private String email;
	static int cnt = 0;
	public Person() {
		this.id = null;
		this.name = null;
		this.email = null;
	}
	public Person(String type, String name, String email) {
		
		this.id = generate(type);
		this.name = name;
		this.email = email;
	}
	public String getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	public String getEmail() {
		return email;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public static String generate(String type) {
		cnt++;
		return type+cnt; 
	}
	@Override
	public String toString() {
		return "Person [id=" + id + ", name=" + name + ", email=" + email + "]";
	}

}
