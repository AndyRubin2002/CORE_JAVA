import java.util.Arrays;

public class Vendor extends Person {
	private String phn;
	private String[] products;
	public Vendor() {
		super();
		this.phn = null;
		this.products = null;
	}
	public Vendor(String name, String email, String phn, String[] products) {
		super("V",name,email);
		this.phn = phn;
		this.products = products;
	}

	public String getPhn() {
		return phn;
	}
	public String[] getProducts() {
		return products;
	}

	public void setPhn(String phn) {
		this.phn = phn;
	}
	public void setProducts(String[] products) {
		this.products = products;
	}
	@Override
	public String toString() {
		return super.toString()+"Vendor [phn=" + phn + ", products=" + Arrays.toString(products) + "]";
	}
	
}
