
public class IndividualCustomer extends Customer {
	private String Mob;

	public IndividualCustomer() {
		super();
		Mob = null;
	}

	public IndividualCustomer(String name, String email,String creditClass, double discounts, String planAssigned,String mob) {
		super("CI",name,email,creditClass,discounts,planAssigned);
		Mob = mob;
	}

	public String getMob() {
		return Mob;
	}

	public void setMob(String mob) {
		Mob = mob;
	}

	@Override
	public String toString() {
		return super.toString()+"IndividualCustomer [Mob=" + Mob + "]";
	}
	
}
