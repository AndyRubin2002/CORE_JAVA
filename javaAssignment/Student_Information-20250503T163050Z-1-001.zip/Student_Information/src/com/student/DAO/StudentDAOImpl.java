package com.student.DAO;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

import com.student.Entity.Student;

public class StudentDAOImpl implements StudentDAO {
	static List<Student> st = new ArrayList<>();
	
	static {
		
		st.add(new Student(104, "David", "10th", 65.0, "david@example.com", "6543217890",new Date()));
        st.add(new Student(105, "Eve", "12th", 88.1, "eve@example.com", "7890123456",new Date()));
		st.add(new Student(101, "Alice", "10th", 85.5, "alice@example.com", "1234567890",new Date()));
        st.add(new Student(102, "Bob", "12th", 78.9, "bob@example.com", "9876543210",new Date()));
        st.add(new Student(103, "Charlie", "11th", 92.3, "charlie@example.com", "4567891230",new Date()));
        
	}

	
	@Override
	public boolean addStd(Student s) {
		st.add(s);
		return true;
	}


	@Override
	public List<Student> displayStd() {
		return st;
		
	}


	@Override
	public Student findByRno(int rno) {
		int pos = -1;
		pos = st.indexOf(new Student(rno));
		
		return st.get(pos);
	}


	@Override
	public List<Student> DisplayByName(String name) {
		List<Student> student = new ArrayList<>();	
//		return student = st.stream()
//				.filter(s->s.getName().equalsIgnoreCase(name))
//				.collect(Collectors.toList());
		
		for(Student s:st) {
			if(s.getName().equals(name)) {
				student.add(s);
			}
		}
		return student;

	}


	@Override
	public boolean deleteStudentByR(int rno) {
		return st.removeIf(s->s.getRollno() == rno);
	}


	@Override
	public boolean modifyName(int rno, String name) {
		Iterator<Student> it = st.iterator();
		
		while(it.hasNext()) {
			Student s = it.next();
			if(s.getRollno() == rno) {
				s.setName(name);
				return true;
			}
		}
		return false;
	}


	@Override
	public List<Student> arrangeByName() {
		List<Student> slist = new ArrayList<>();
		for(Student s : st)
		{
			slist.add(s);
		}
		Comparator<Student> cst = (s1,s2)->s1.getName().compareTo(s2.getName());
		
		slist.sort(cst);
		return slist;
	}


	@Override
	public List<Student> arrangeByRno() {
		List<Student> slist = new ArrayList<>();
		for(Student s : st)
		{
			slist.add(s);
		}
		Comparator<Student> cst = (s1,s2)->s1.getRollno() - s2.getRollno();
		
		slist.sort(cst);
		return slist;
	}
	
	

}
