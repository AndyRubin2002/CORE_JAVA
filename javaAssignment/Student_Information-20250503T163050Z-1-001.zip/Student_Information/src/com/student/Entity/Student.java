package com.student.Entity;

import java.util.Date;
import java.util.Objects;

public class Student{
	private int rollno;
	private String name;
	private String std;
	private double per;
	private String email;
	private String mob;
	private Date dob;
	
	public Student() {
		super();
	}
	public Student(int rollno, String name, String std, double per, String email, String mob, Date dob) {
		super();
		this.rollno = rollno;
		this.name = name;
		this.std = std;
		this.per = per;
		this.email = email;
		this.mob = mob;
		this.dob = dob;
	}
	
	public Student(int rno) {
		this.rollno = rno;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public int getRollno() {
		return rollno;
	}
	public String getName() {
		return name;
	}
	public String getStd() {
		return std;
	}
	public double getPer() {
		return per;
	}
	public String getEmail() {
		return email;
	}
	public String getMob() {
		return mob;
	}
	public void setRollno(int rollno) {
		this.rollno = rollno;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setStd(String std) {
		this.std = std;
	}
	public void setPer(double per) {
		this.per = per;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public void setMob(String mob) {
		this.mob = mob;
	}
	
	@Override
	public String toString() {
		return "Student [rollno=" + rollno + ", name=" + name + ", std=" + std + ", per=" + per + ", email=" + email
				+ ", mob=" + mob + ", dob=" + dob + "]";
	}
	
	@Override
	public boolean equals(Object obj) {
		
		Student other = (Student) obj;
		return rollno == other.rollno;
	}
	
	
	
	

}
