
public class StudentEntity {
	private int sid;
	private String sname;
	private int m1, m2, m3;
	private double gpa;
	public StudentEntity() {
		
		this.sid = 0;
		this.sname = null;
		this.m1 = 0;
		this.m2 = 0;
		this.m3 = 0;
		this.gpa = calculateGPA();
	}
	public StudentEntity(int sid, String sname, int m1, int m2, int m3) {
		
		this.sid = sid;
		this.sname = sname;
		this.m1 = m1;
		this.m2 = m2;
		this.m3 = m3;
		this.gpa = calculateGPA();
	}
	private double calculateGPA() {
		
		return ((1.0/3)*this.m1)+((1.0/2)*this.m2)+((1.0/4)*this.m3) ;
	}
	public int getSid() {
		return sid;
	}
	public String getSname() {
		return sname;
	}
	public int getM1() {
		return m1;
	}
	public int getM2() {
		return m2;
	}
	public int getM3() {
		return m3;
	}
	public double getGpa() {
		return gpa;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public void setM1(int m1) {
		this.m1 = m1;
	}
	public void setM2(int m2) {
		this.m2 = m2;
	}
	public void setM3(int m3) {
		this.m3 = m3;
	}
	public void setGpa(double gpa) {
		this.gpa = gpa;
	}
	@Override
	public String toString() {
		return "StudentEntity [sid=" + sid + ", sname=" + sname + ", m1=" + m1 + ", m2=" + m2 + ", m3=" + m3 + ", gpa="
				+ gpa + "]";
	}
	

}
