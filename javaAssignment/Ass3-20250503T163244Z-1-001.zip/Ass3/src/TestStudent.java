import java.util.Scanner;

public class TestStudent {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		int choice = 0;
		do {
			System.out.println("1. Add Student ");
			System.out.println("2. Display Student ");
			System.out.println("3. Find By Name ");
			System.out.println("4. Find by ID ");
			System.out.println("5. calculate GPA of a student ");
			System.out.println("6. Exit ");
			System.out.println("Enter the choice :");
			choice = sc.nextInt();
			
			switch (choice) {
			case 1:
				StudentInfo.addStudent();
				break;
			case 2:
				StudentInfo.display();
				break;
			
			case 3:
				System.out.println("Enter your Name :");
				String name = sc.next();
				StudentEntity[] res =StudentInfo.findStudent(name);
				for(int i = 0; i<res.length; i++) {
					if(res[i] != null) {
						System.out.println(res[i]);
					}
				}
				break;
			case 4:
				System.out.println("Enter your id :");
				int id = sc.nextInt();
				System.out.println(StudentInfo.findByID(id));
				break;
				
			case 5:
				System.out.println("Enter your id :");
				 id = sc.nextInt();
				StudentInfo.getGPA(id);
				break;
				
			case 6:
				sc.close();
				System.out.println("Exit");
				break;
			default:
				System.out.println("Thank you");
				break;
			}
		}while(choice != 6);

	}

}
