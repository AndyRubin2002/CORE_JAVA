import java.util.Scanner;

public class StudentInfo {
	
	static StudentEntity[] stu = new StudentEntity[50];
	static int cnt = 0;
	
	static {
		stu[0]=new StudentEntity(112,"Deepa",45,67,78);
		stu[1]=new StudentEntity(113,"Seema",45,67,78);
		stu[2]=new StudentEntity(114,"Sangeeta",45,67,78);
		cnt=3;
	}
	//Add Friend
	public static void addStudent()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your id :");
		int id = sc.nextInt();
		System.out.println("Enter your Name :");
		String name = sc.next();
		System.out.println("Enter the M1 :");
		int m1 = sc.nextInt();
		System.out.println("Enter the M2 :");
		int m2 = sc.nextInt();
		System.out.println("Enter the M3 :");
		int m3 = sc.nextInt();
		
		
		stu[cnt++] = new StudentEntity(id,name,m1,m2,m3);
		System.out.println("Friend Added");
	}
	
	//Display
	public static void display() {
		for(int i = 0; i<cnt; i++) {
			System.out.println(stu[i]);
		}
	}
	
	
	//Find By Name
	public static StudentEntity[] findStudent(String name) {
		StudentEntity[] farr = new StudentEntity[cnt];
		int idx = 0;
		for(int i = 0; i<cnt; i++) {
			if(stu[i].getSname().equals(name)) {
				farr[idx++] = stu[i];
			}
		}
		
		return farr;
	}
	
	//Find By id
		public static StudentEntity findByID(int id) {
			for(int i = 0; i<cnt; i++) {
				if(stu[i].getSid() == id) {
					return stu[i];
				}
			}
			
			return null;
		}
		
	//calculate gpa
		public static void getGPA(int id) {
			for(int i = 0; i<cnt; i++) {
				if(stu[i].getSid() == id) {
					System.out.println(stu[i].getGpa());
				}
			}
			System.out.println("error");
		}

}
