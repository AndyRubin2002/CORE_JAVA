import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class TestDataInputStream {
	public static void main(String[] args) {
		try(DataOutputStream dos = new DataOutputStream(new FileOutputStream("t.txt"));
			DataInputStream dis = new DataInputStream(new FileInputStream("t.txt"))) {
			dos.writeInt(101);
			dos.writeUTF("Ram");
			dos.writeDouble(763476.67);
			
			System.out.println("Integer :"+ dis.readInt());
			System.out.println("String :"+ dis.readUTF());
			System.out.println("Double :"+ dis.readDouble());
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
		
			e.printStackTrace();
		}
	}
}
