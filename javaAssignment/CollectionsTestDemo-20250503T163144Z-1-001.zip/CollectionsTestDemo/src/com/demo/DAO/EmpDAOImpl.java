package com.demo.DAO;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

import com.demo.Entity.ContractEmp;
import com.demo.Entity.Emp;
import com.demo.Entity.SalariedEmp;

public class EmpDAOImpl implements EmpDAO{
	static List<Emp> elist = new ArrayList<>();
	static {
		
		elist.add(new SalariedEmp("Kavita","25545244","jsdjsg@gmail.com",new Date(), "Hr","mgr",34252));
		elist.add(new SalariedEmp("Ram","2145454","jsdjsg@gmail.com",new Date(), "Admin","mgr",30000));
		elist.add(new ContractEmp("Rajesh","24545643","jsdjsg@gmail.com",new Date(), "hr","mgr",20, 1000));
		elist.add(new ContractEmp("Ramesh","23536686","jfgdfgsg@gmail.com",new Date(), "Sales","mgr",15, 2000));
		
	}
	
	
	// User data Added into List
	@Override
	public boolean save(Emp e) {
		elist.add(e);
		return true;
	}
	

	// Returning the List
	@Override
	public List<Emp> findAll() {
		return elist;
	}
	

	//Find Employee By id And Returning
	@Override
	public Emp getById(String id) {
//		for(Emp e : elist) {
//			if(e.getId().equalsIgnoreCase(id)) {
//				return e;
//			}
//		}
//		return null;
		
		int pos = -1;
		
		if(id.startsWith("S")) {
			pos = elist.indexOf(new SalariedEmp(id));
		}else {
			pos = elist.indexOf(new ContractEmp(id));
		}
		
		if(pos != -1) {
			return elist.get(pos);
		}
		return null;
	}
	
	
	//Find Employee By Name And Returning
	@Override
	public List<Emp> findByName(String name) {
		List<Emp> res ;
		
//		for(Emp e : elist) {
//			if(e.getName().equalsIgnoreCase(name)) {
//				res.add(e);
//			}
//		}
//		return res;
		
		
		//Iterator 
		
		
//		Iterator<Emp> it = elist.iterator();
//		
//		while(it.hasNext())
//		{
//			if(it.next().getName().equals(name))
//			{
//				res.add(it.next());
//			}
//		}
//		if(res.size() > 0) {
//			return res;
//		}
//		return null;
		
		
		res= elist.stream()
				.filter(e-> { return e.getName().equals(name);})
				.collect(Collectors.toList());
		if(res.size() > 0)
		{
			return res;
		}
		return null;
		
		
	}
	

	//Deleting Employee from List 
	@Override
	public boolean deleteEmp(String id) {
//		for(Emp e : elist) {
//			if(e.getId().equalsIgnoreCase(id)) {
//				elist.remove(e);
//				return true;
//			}
//		}
//		return false;
		
		return elist.removeIf(e->e.getId().equals(id));
		
	}
	

	// Modifying the Employee Name 
	@Override
	public boolean updateName(String id, String name) {
//		for(Emp e : elist) {
//			if(e.getId().equalsIgnoreCase(id)) {
//				e.setName(name);
//				return true;
//			}
//		}
//		return false;
		
		
		Iterator<Emp> it = elist.iterator();

		while (it.hasNext()) {
		    Emp emp = it.next(); 
		    if (emp.getId().equals(id)) { 
		        if (emp instanceof SalariedEmp) { 
		            ((SalariedEmp) emp).setName(name); 
		            return true;
		        } else if (emp instanceof ContractEmp) {
		            ((ContractEmp) emp).setName(name); 
		            return true;
		        }
		    }
		}

		return false;

	}
	
	
	public static List<Emp> customSort(List<Emp> list) {
	    Collections.sort(list, new Comparator<Emp>() {
	        @Override
	        public int compare(Emp i1, Emp i2) {
	            return i1.getName().compareTo(i2.getName()); // Ascending order
	        }
	    });
	    return list;
	}



	@Override
	public List<Emp> sortByN() {
		return customSort(elist);
	}

	@Override
	public List<Emp> sortById() {
		// TODO Auto-generated method stub
		return null;
	}


}
