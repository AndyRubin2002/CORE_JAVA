package com.demo.Test;

import java.util.List;
import java.util.Scanner;

import com.demo.Entity.Emp;
import com.demo.Services.EmpServices;
import com.demo.Services.EmpServicesImpl;

public class TestEmp {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		EmpServices EI = new EmpServicesImpl();
		
		int choice;
		
		do {
			System.out.println("1. Adding the new Employees");
			System.out.println("2. Display the Employees");
			System.out.println("3. Find Employee By ID");
			System.out.println("4. Find Employee By Name");
			System.out.println("5. Delete Employees");
			System.out.println("6. Modify Employee");
			System.out.println("7. display in sorted order by name");
			System.out.println("8. Display in sorted order by id");
			System.out.println("9. Exit");
			System.out.println("Enter Your Choice :");
			choice = sc.nextInt();
			
			switch (choice) {
			
			case 1:System.out.println("1.Salaried Employee\n2.Contract Employee\n which Employee");
				int ch = sc.nextInt();
				boolean status = EI.addEmployees(ch);
				if(status)
				{
					System.out.println("Employee Added Successfully");
				}
				else {
					System.out.println("Sorry");
				}
				break;
				
			case 2:
				List<Emp> list = EI.DisplayEmp();
				list.forEach(i->{System.out.println(i);});
				break;
				
			case 3:
				System.out.println("Enter the id :");
				String id = sc.next();
				
				Emp e = EI.findById(id);
				if(e != null) {
					System.out.println(e);
				}else {
					System.out.println("Not found");
				}
				break;
				
			case 4:
				System.out.println("Enter the name:");
				String name = sc.next();
				
				list = EI.findByName(name);
				if(!list.isEmpty()) {
					list.forEach(i->{System.out.println(i);});
				}else {
					System.out.println("Not found");
				}
				break;
				
			case 5:
				System.out.println("Enter the id :");
				id = sc.next();
				
				
				if(EI.deleteEmp(id)) {
					System.out.println("deleted a Employee");
				}else {
					System.out.println("Not found");
				}
				break;
				
			case 6:
				System.out.println("Enter the id :");
				id = sc.next();
				
				System.out.println("Enter the name to modify :");
				name = sc.next();
				
				if(EI.modifyEmp(id, name)) {
					System.out.println("Name Modify Sccessfully.");
				}else {
					System.out.println("Not found");
				}
				break;
				
			case 7:
				List<Emp> em = EI.sortByName();
				em.forEach(i->{System.out.println(i);});
				break;
				
			case 8:
				List<Emp> en = EI.sortById();
				en.forEach(i->{System.out.println(i);});
				break;
				
			case 9:
				sc.close();
				System.out.println("Thank you");
				break;

			default:
				System.out.println("wrong choice");
				break;
			}
			
		}while(choice!=9);

	}


}
