import java.util.Scanner;

public class Guess_Number {
	public static void main(String[] args)  {
		int num = 23;
		Scanner sc = new Scanner(System.in);
		
		int n = 0;
		do {
			try {
				System.out.println("Guess the number :");
				n= sc.nextInt();
				
				if(num!=n)
				{
					System.out.println("wrong");
					throw new WrongNumberException(" Wrong ");
				}
				else {
					System.out.println("Correct");
					break;
				}
				
			}
			catch(WrongNumberException e)
			{
				System.out.println(e.getMessage());
			}
			catch(Exception e)
			{
				System.out.println(e.getMessage());
			}
			
		}while(num != n);
	}

}
