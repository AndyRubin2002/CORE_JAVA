package company;

import java.util.Date;

public class ContractEmp extends Employee {
	private int hrs;
	private double charges;
	
	public ContractEmp() {
		super();
		this.hrs = 0;
		this.charges = 0;
	}
	
	public ContractEmp(String name, String mobNo,Date dob, String dept, String desg,int hrs, double charges) {
		super("c",name,mobNo,dob,dept,desg);
		this.hrs = hrs;
		this.charges = charges;
	}
	public int getHrs() {
		return hrs;
	}
	public double getCharges() {
		return charges;
	}
	public void setHrs(int hrs) {
		this.hrs = hrs;
	}
	public void setCharges(double charges) {
		this.charges = charges;
	}
	@Override
	public String toString() {
		return super.toString()+"\nContractEmp [hrs=" + hrs + ", charges=" + charges + "]";
	}
	
	

}
