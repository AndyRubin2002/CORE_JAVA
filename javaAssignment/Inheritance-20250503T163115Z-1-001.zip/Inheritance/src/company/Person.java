package company;
import java.util.Date;


public class Person {
	private String id;
	private String Name;
	private String MobNo;
	private Date dob;
	static int cnt=0;
	
	public Person() {
		this("s",null,null,new Date());
		
	}

	private String generateId(String type) {
		cnt++;
		return type+cnt;
	}

	public Person(String type, String name, String mobNo, Date dob) {
		super();
		this.id = generateId(type);
		Name = name;
		MobNo = mobNo;
		this.dob = dob;
		
	}

	public String getId() {
		return id;
	}

	public String getName() {
		return Name;
	}

	public String getMobNo() {
		return MobNo;
	}


	public void setName(String name) {
		Name = name;
	}

	public void setMobNo(String mobNo) {
		MobNo = mobNo;
	}

	@Override
	public String toString() {
		return "Person [id=" + id + ", Name=" + Name + ", MobNo=" + MobNo + ", dob=" + dob + "]";
	}

	
	
	

}
