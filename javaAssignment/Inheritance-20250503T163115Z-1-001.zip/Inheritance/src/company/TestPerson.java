package company;
import java.util.Date;
public class TestPerson {

	public static void main(String[] args) {
//		SalEmp em = new SalEmp("Mukesh","8734623",new Date(),"hr","mgr",453456);
//		System.out.println(em);
//		SalEmp em1 = new SalEmp("Rohna","8734623",new Date(),"hr","mgr",453456);
//		System.out.println(em1);
//		ContractEmp C1 = new ContractEmp("suresh","8734623",new Date(),"hr","mgr",5,300);
//		System.out.println(C1);
		Vender v1 = new Vender("suresh","8734623",new Date(),"hr","mgr",1000, 5);
		System.out.println(v1);

	}

}
