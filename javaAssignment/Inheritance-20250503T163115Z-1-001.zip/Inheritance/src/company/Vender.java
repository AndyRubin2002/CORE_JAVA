package company;

import java.util.Date;

public class Vender extends Employee{
	private double Rate;
	private int NoEmp;
	public Vender() {
		super();
		Rate = 0;
		NoEmp = 0;
	}
	public Vender(String name, String mobNo,Date dob, String dept, String desg,double rate, int noEmp) {
		super("v",name,mobNo,dob,dept,desg);
		Rate = rate;
		NoEmp = noEmp;
	}
	public double getRate() {
		return Rate;
	}
	public int getNoEmp() {
		return NoEmp;
	}
	public void setRate(double rate) {
		Rate = rate;
	}
	public void setNoEmp(int noEmp) {
		NoEmp = noEmp;
	}
	@Override
	public String toString() {
		return super.toString()+"\nVender [Rate=" + Rate + ", NoEmp=" + NoEmp + "]";
	}
	
	

}
