package com.emp.entity;


import java.util.Date;

public class Person {
	private int id;
	private String name;
	private String mob,email;
	private Date doj;
	public Person() {
		super();
		this.id = 0;
		this.name = null;
		this.mob = null;
		this.email = null;
		this.doj = null;
	}
	public Person(int id, String name, String mob, String email, Date doj) {
		super();
		this.id = id;
		this.name = name;
		this.mob = mob;
		this.email = email;
		this.doj = doj;
	}

	

	public int getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	public String getMob() {
		return mob;
	}
	public String getEmail() {
		return email;
	}
	public Date getDoj() {
		return doj;
	}
	public void setId(int id) {
		this.id = id;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setMob(String mob) {
		this.mob = mob;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public void setDoj(Date doj) {
		this.doj = doj;
	}
	@Override
	public String toString() {
		return "Person [id=" + id + ", name=" + name + ", mob=" + mob + ", email=" + email + ", doj=" + doj + "]";
	}
	
	@Override
	public int hashCode() {
		return this.id;
	}
	
	@Override
	public boolean equals(Object obj) {
		
		Person other = (Person) obj;
		return id == other.id;
	}
	
	
	
	
	
	

}
