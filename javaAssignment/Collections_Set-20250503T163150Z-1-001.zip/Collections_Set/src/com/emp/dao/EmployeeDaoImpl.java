package com.emp.dao;



import java.sql.Date;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

import com.emp.entity.Emp;
import com.emp.entity.SalariedEmp;
import com.emp.entity.ContractEmp;
public class EmployeeDaoImpl implements EmployeeDao{
	static Set<Emp> eset = new HashSet<>();
	
	static {
			
			eset.add(new SalariedEmp(100,"Kavita","25545244","jsdjsg@gmail.com",new Date(27,05,2002), "Hr","mgr",34252));
			eset.add(new SalariedEmp(2,"Suresh","2145454","jsdjsg@gmail.com",new Date(23,04,2024), "Admin","mgr",30000));
			eset.add(new ContractEmp(400,"Pranit","24545643","bvgdfg@gmail.com",new Date(43,02,2002), "hr","mgr",20, 1000));
			eset.add(new ContractEmp(1,"Suresh","23536686","jfgdfgsg@gmail.com",new Date(26,04,2025), "Sales","mgr",15, 2000));
			eset.add(new ContractEmp(567,"Ramesh","45645","fbvgxcfg@gmail.com",new Date(26,04,2015), "Sales","mgr",15, 2000));
			eset.add(new SalariedEmp(6,"Akshay","4565665465","asdfdd@gmail.com",new Date(12,04,2024), "Admin","mgr",30000));
		}
	
	@Override
	public boolean save(Emp e) {
		return eset.add(e);
	}
	

	@Override
	public Set<Emp> displayEmployee() {
		return eset;
	}

	@Override
	public Emp findByID(int id) {
		Optional<Emp> e = eset.stream().filter(s->s.getId()==id).findFirst();
		if(e.isPresent()) {
			return e.get();
		}
		return null;
	}


	@Override
	public List<Emp> findByName(String name) {
//		List<Emp> list = eset.stream().filter(e->e.getName().equals(name)).collect(Collectors.toList());
//		return list;
		
		List<Emp> list = new ArrayList<>();
		
		Iterator<Emp> it = eset.iterator();
		
		while(it.hasNext())
		{
			Emp e = it.next();
			if(e.getName().equals(name))
			{
				list.add(e);
			}
		}
		if(list.size()>0)
		{
			return list;
		}
		return null;
	}


	@Override
	public boolean removeById(int id) {
		Emp e = findByID(id);
		if(e != null) {
			eset.remove(e);
			return true;
		}
		return false;
	}


	@Override
	public boolean updateName(int id, String name) {
		Emp e = findByID(id);
		if(e != null) {
			e.setName(name);
			return true;
		}
		return false;
//		
//		Optional<Emp>e1 = eset.stream().filter(e->{
//			if(e.getId() == id) {
//				e.setName(name);
//				return true;
//			}
//			return false;
//		}).findFirst();
//		
//		if(e1.isPresent()) {
//			return true;
//		}
//		return false;
	}


	@Override
	public List<Emp> sortByName() {
		Comparator<Emp> e = (e1,e2)->{
			return e1.getName().compareTo(e2.getName());
		};
		List<Emp> list = new ArrayList<>();
		
		for(Emp em : eset) {
			list.add(em);
		}
		
		list.sort(e);
		return list;
	}


	@Override
	public Set<Emp> sortByID() {
		Comparator<Emp> e12 = (e1,e2)-> e1.getId()-e2.getId();
		Set<Emp> set =new TreeSet<>(e12);
		
		for(Emp e : eset) {
			set.add(e);
		}
		
		return set;
	}


	@Override
	public List<Emp> orderBySal() {
		Comparator<Emp> e = (e1,e2)->{
			double s1 = 0, s2 = 0;
			if(e1 instanceof SalariedEmp) {
				s1 = ((SalariedEmp) e1).getSal();
			}else if(e1 instanceof ContractEmp) {
				s1 = ((ContractEmp) e1).getCharges();
			}
			if(e2 instanceof SalariedEmp) {
				s2 = ((SalariedEmp) e2).getSal();
			}else if(e2 instanceof ContractEmp) {
				s2 = ((ContractEmp) e2).getCharges();
			}
			return (int) (s1-s2);
		};
		List<Emp> list = new ArrayList<>();
		for(Emp em : eset) {
			list.add(em);
		}
		list.sort(e);
		return list;
		
		
		
	}
	
	
	
}
