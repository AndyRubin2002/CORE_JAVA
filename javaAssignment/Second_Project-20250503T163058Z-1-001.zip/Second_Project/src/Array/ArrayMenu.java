package Array;

import java.util.Scanner;

public class ArrayMenu {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size of array :");
		int n = sc.nextInt();
		int arr[] = new int[n];
		System.out.println("Enter the Elements of array :");
		ArrayService.accept(arr);
		System.out.println("Array is :");
		ArrayService.Display(arr);
		
		int ch;
		do {
			System.out.println("----------------------------------------");
			System.out.println("1.Max element from Array ");
			System.out.println("2.Min element from Array ");
			System.out.println("3.Addition of Array Elements ");
			System.out.println("4.Addition of prime numbers ");
			System.out.println("5.Exit ");
			System.out.println("----------------------------------------");
			System.out.println("Enter the Choice");
			ch = sc.nextInt();
			
			
			
			switch(ch) {
			
			case 1: ArrayService.maxElement(arr);
					break;
					
			case 2: ArrayService.minElement(arr);
					break;
					
			case 3:	ArrayService.addArray(arr);
					break;
					
			case 4: ArrayService.addPrime(arr);
					break;
					
			case 5: 
					System.out.println("Exit");
					break;
			
			default: System.out.println("You enter the wrong choice");
					break;
			}
			
			
		}while(ch!=5);
		
		
		
		sc.close();

	}

}
