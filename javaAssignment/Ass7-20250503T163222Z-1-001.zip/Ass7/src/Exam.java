
import java.util.Arrays;
import java.util.Date;
public class Exam {
	private int examid;
	private String name ,topic;
	private Date date; 
	private Questions question[];
	public Exam(int examid, String name, String topic, Date date, Questions[] question) {
		this.examid = examid;
		this.name = name;
		this.topic = topic;
		this.date = date;
		this.question = question;
	}
	public int getExamid() {
		return examid;
	}
	public String getName() {
		return name;
	}
	public String getTopic() {
		return topic;
	}
	public Date getDate() {
		return date;
	}
	public Questions[] getQuestion() {
		return question;
	}
	public void setExamid(int examid) {
		this.examid = examid;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setTopic(String topic) {
		this.topic = topic;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public void setQuestion(Questions[] question) {
		this.question = question;
	}
	
	
	@Override
	public String toString() {
		return "Exam [examid=" + examid + ", name=" + name + ", topic=" + topic + ", date=" + date + ", question="
				+ Arrays.toString(question) + "]";
	}
	
	
	
	
}
