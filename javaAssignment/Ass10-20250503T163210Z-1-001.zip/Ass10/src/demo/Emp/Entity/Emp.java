package demo.Emp.Entity;

import java.util.Objects;

public class Emp implements Comparable<Emp>{

	private int  id;
	private String name,dept, designation;
	private double sal;
	
	public Emp() {
		super();
	}
	
	public Emp(int id) {
		super();
		this.id = id;
	}

	public Emp(String name, String dept, String designation, double sal) {
		this.name = name;
		this.dept = dept;
		this.designation = designation;
		this.sal = sal;
	}

	public Emp(int id, String name, String dept, String designation, double sal) {
		super();
		this.id = id;
		this.name = name;
		this.dept = dept;
		this.designation = designation;
		this.sal = sal;
	}
	
	public int getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	public String getDept() {
		return dept;
	}
	public String getDesignation() {
		return designation;
	}
	public double getSal() {
		return sal;
	}
	public void setId(int id) {
		this.id = id;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public void setSal(double sal) {
		this.sal = sal;
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(id);
	}

	@Override
	public boolean equals(Object obj) {
		Emp other = (Emp) obj;
		return id == other.id;
	}

	@Override
	public String toString() {
		return "Emp [id=" + id + ", name=" + name + ", dept=" + dept + ", designation=" + designation + ", sal=" + sal
				+ "]";
	}
	
	@Override
	public int compareTo(Emp o) {
		return this.id -o.id;
	}
	
	public String display() {
		return "Emp [name=" + name + ", dept=" + dept + ", designation=" + designation + ", sal=" + sal
				+ "]";
	}
	
}
