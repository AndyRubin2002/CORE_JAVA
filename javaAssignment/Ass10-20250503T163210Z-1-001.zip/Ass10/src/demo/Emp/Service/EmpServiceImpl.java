package demo.Emp.Service;

import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import demo.Emp.DAO.EmpDao;
import demo.Emp.DAO.EmpDaoImpl;
import demo.Emp.Entity.Emp;

public class EmpServiceImpl implements EmpService {

	static EmpDao edao;
	static {
		edao = new EmpDaoImpl();
	}
	@Override
	public boolean addEmp() {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Employee ID :");
		int id = sc.nextInt();
		sc.nextLine();
		System.out.println("Enter Employee Name :");
		String name = sc.nextLine();
		System.out.println("Enter Employee Department :");
		String dept = sc.nextLine();
		System.out.println("Enter Employee Designation :");
		String desg = sc.nextLine();
		System.out.println("Enter Employee Salary :");
		double sal = sc.nextDouble();
		
		return edao.save(new Emp(id, name, dept, desg, sal));
		
	}
	@Override
	public Set<Emp> displayAll() {
		return edao.findAll();
		
	}
	@Override
	public Emp findById(int id) {
		return edao.displayById(id);
	}
	@Override
	public List<Emp> findByName(String name) {
		return edao.displayByName(name);
	}
	@Override
	public boolean deleteEmp(int id) {
		return edao.removeEmp(id);
	}
	@Override
	public boolean updateBySal(int id, double sal) {
		return edao.modifySal(id,sal);
	}
	@Override
	public List<Emp> sortByName() {
		// TODO Auto-generated method stub
		return edao.sortName();
	}
	@Override
	public Set<Emp> sortById() {
		return edao.sortById();
	}
	@Override
	public List<Emp> sortBySal() {
		return edao.arrangeBySal();
	}
	@Override
	public Map<Integer, Emp> storeInTreeMap() {
		return edao.storeMap();
	}
	
}
