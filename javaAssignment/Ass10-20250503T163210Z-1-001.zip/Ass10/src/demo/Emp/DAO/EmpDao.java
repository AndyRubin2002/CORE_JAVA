package demo.Emp.DAO;

import java.util.List;
import java.util.Map;
import java.util.Set;

import demo.Emp.Entity.Emp;

public interface EmpDao {

	boolean save(Emp emp);

	Set<Emp> findAll();

	Emp displayById(int id);

	List<Emp> displayByName(String name);

	boolean removeEmp(int id);

	boolean modifySal(int id, double sal);

	List<Emp> sortName();

	Set<Emp> sortById();

	List<Emp> arrangeBySal();

	Map<Integer, Emp> storeMap();

}
