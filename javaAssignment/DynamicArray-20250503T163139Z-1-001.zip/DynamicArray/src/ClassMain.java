
public class ClassMain {

	public static void main(String[] args) {
		int[][] arr = new int[3][];
		ArrayService.AcceptArray(arr);
		ArrayService.Display(arr);
	}

}
