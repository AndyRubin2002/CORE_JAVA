package polymorphism;

import java.util.Date;

public class ContractEmp extends Emp{
	private int hrs;
	private double charges;
	
	public ContractEmp() {
		super();
	}
	public ContractEmp(String name, String mob,String email, Date date, String dept, String desc, int hrs, double charges) {
		super("C", name, mob,email, date, dept, desc);
		this.hrs = hrs;
		this.charges = charges;
	}
	
	public int getHrs() {
		return hrs;
	}
	public double getCharges() {
		return charges;
	}
	public void setHrs(int hrs) {
		this.hrs = hrs;
	}
	public void setCharges(double charges) {
		this.charges = charges;
	}
	
	public double calSalary()
	{
		return hrs*charges;
	}
	@Override
	public String toString() {
		return super.toString()+"ContractEmp [hrs=" + hrs + ", charges=" + charges + "]";
	}
	
	

}
