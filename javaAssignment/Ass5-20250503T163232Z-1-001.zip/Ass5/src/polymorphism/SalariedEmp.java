package polymorphism;

import java.util.Date;

public class SalariedEmp extends Emp{
	private double sal;
	private double bonus;
	
	public SalariedEmp() {
		super();
		this.sal = 0;
		this.bonus = 0;
	}
	
	public SalariedEmp(String name, String mob,String email, Date date, String dept, String desc, double sal) {
		super("S", name, mob,email, date, dept, desc);
		this.sal = sal;
		this.bonus = sal*0.10;
	}
	
	public double getSal() {
		return sal;
	}
	public double getBonus() {
		return bonus;
	}
	public void setSal(double sal) {
		this.sal = sal;
	}
	public void setBonus(double bonus) {
		this.bonus = bonus;
	}
	
	
	
	public double calSalary() {
		return this.sal+0.10*this.sal+0.15*this.sal-0.12*this.sal+this.bonus;
	}
	
	@Override
	public String toString() {
		return super.toString()+"SalariedEmp [sal=" + sal + ", bonus=" + bonus + "]";
	}

}
