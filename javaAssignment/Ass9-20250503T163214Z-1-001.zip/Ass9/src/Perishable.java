import java.util.Date;

public class Perishable extends Product {
	private Date Exp_date;
	private double price;
	public Perishable(int id, String name, Date mfgdate, double price, Date exp_date) {
		super(id,name,"Perishable",mfgdate);
		Exp_date = exp_date;
		this.price = price;
	}

	public Date getExp_date() {
		return Exp_date;
	}

	public double getPrice() {
		return price;
	}

	public void setExp_date(Date exp_date) {
		Exp_date = exp_date;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public double calculateTax()
	{
		return this.price*0.05;
	}

	@Override
	public String toString() {
		return super.toString()+"Perishable [Exp_date=" + Exp_date + ", price=" + price + "]";
	}

	
}
