import java.util.Date;

public class TestProduct {

	public static void main(String[] args) {
		
		Perishable pr = new Perishable(1,"Table",new Date(),2000, new Date());
		System.out.println(pr);
		System.out.println(pr.calculateTax());
		
		NonPerishable pr1 = new NonPerishable(2,"Book",new Date(),2000,"furniture, statitionary, utensils");
		System.out.println(pr1);
		System.out.println(pr1.calculateTax());
	}

}
