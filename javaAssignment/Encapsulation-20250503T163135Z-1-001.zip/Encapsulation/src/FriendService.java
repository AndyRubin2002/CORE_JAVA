import java.util.Scanner;

public class FriendService {
	static Friend[] friend = new Friend[50];
	static int cnt = 0;
	
	static {
		friend[0]=new Friend(112,"Deepa","3333");
		friend[1]=new Friend(113,"Seema","44444");
		friend[2]=new Friend(114,"Sangeeta","5555");
		cnt=3;
	}
	//Add Friend
	public static void addFriend()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your id :");
		int id = sc.nextInt();
		System.out.println("Enter your Name :");
		String name = sc.next();
		System.out.println("Enter the Mobile Number :");
		String mob = sc.next();
		
		friend[cnt++] = new Friend(id,name,mob);
		System.out.println("Friend Added");
	}
	
	//Display
	public static void display() {
		for(int i = 0; i<cnt; i++) {
			System.out.println(friend[i]);
		}
	}
	
	//Update
	public static void updateMob(int id,String mob) {
		for(int i = 0; i<cnt; i++) {
			if(friend[i].getFid() == id) {
				friend[i].setMob(mob);
			}
		}
		System.out.println("Mobile Number is Updated");
	}
	
	//Find By Name
	public static Friend[] findFriend(String name) {
		Friend[] farr = new Friend[cnt];
		int idx = 0;
		for(int i = 0; i<cnt; i++) {
			if(friend[i].getName().equals(name)) {
				farr[idx++] = friend[i];
			}
		}
		
		return farr;
	}
	
	//Find By id
		public static Friend findByID(int id) {
			for(int i = 0; i<cnt; i++) {
				if(friend[i].getFid() == id) {
					return friend[i];
				}
			}
			
			return null;
		}
	
	

}
